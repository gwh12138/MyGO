DATABASE = {
    'host': '127.0.0.1',
    'user': 'root',
    'password': '123456',
    'db': 'dbse'
}

SECRET_KEY = b'VaIIM3gAVB3tsT0pPns_-7wwmMDcXoTI7MMS5Ow4s_I='